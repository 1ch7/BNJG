import { useState } from "react";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell,
} from "recharts";
import { Brain, Thermometer, ChevronDown, ChevronUp, Package, Edit3, Check, X, Download, ArrowUpRight, ArrowDownRight, CloudRain, ShoppingCart } from "lucide-react";

const C = {
  bg: "#151A1F", card: "#1A2027", card2: "#1F2831", border: "rgba(255,255,255,0.07)",
  cyan: "#5BEEFC", green: "#16F686", yellow: "#EEE638",
  text: "#FFFFFF", muted: "rgba(255,255,255,0.5)", dim: "rgba(255,255,255,0.22)",
};

// ─── Data ────────────────────────────────────────────────────────────────────

const thisWeekData = [
  { day: "Mon", thisWeek: 142, lastWeek: 118 },
  { day: "Tue", thisWeek: 138, lastWeek: 124 },
  { day: "Wed", thisWeek: 91, lastWeek: 145 },
  { day: "Thu", thisWeek: 155, lastWeek: 131 },
  { day: "Fri", thisWeek: 189, lastWeek: 160 },
  { day: "Sat", thisWeek: 207, lastWeek: 185 },
  { day: "Sun", thisWeek: 0, lastWeek: 198 },
];

const peakHoursData = [
  { hour: "11am", orders: 18 }, { hour: "12pm", orders: 52 }, { hour: "1pm", orders: 74 },
  { hour: "2pm", orders: 48 }, { hour: "3pm", orders: 14 }, { hour: "4pm", orders: 11 },
  { hour: "5pm", orders: 22 }, { hour: "6pm", orders: 55 }, { hour: "7pm", orders: 88 },
  { hour: "8pm", orders: 95 }, { hour: "9pm", orders: 62 }, { hour: "10pm", orders: 28 },
];

const customerTypeData = [
  { day: "Mon", family: 38, individual: 62, group: 0 },
  { day: "Tue", family: 35, individual: 58, group: 7 },
  { day: "Wed", family: 20, individual: 72, group: 8 },
  { day: "Thu", family: 30, individual: 60, group: 10 },
  { day: "Fri", family: 25, individual: 55, group: 20 },
  { day: "Sat", family: 52, individual: 32, group: 16 },
  { day: "Sun", family: 58, individual: 28, group: 14 },
];

const weatherSalesData = [
  { day: "Jun 9", temp: 24, customers: 142 }, { day: "Jun 10", temp: 22, customers: 138 },
  { day: "Jun 11", temp: 17, customers: 91 }, { day: "Jun 12", temp: 15, customers: 78 },
  { day: "Jun 13", temp: 19, customers: 165 }, { day: "Jun 14", temp: 26, customers: 198 },
  { day: "Jun 15", temp: 27, customers: 207 }, { day: "Jun 16", temp: 21, customers: 130 },
  { day: "Jun 17", temp: 18, customers: 95 }, { day: "Jun 18", temp: 23, customers: 148 },
  { day: "Jun 19", temp: 25, customers: 155 }, { day: "Jun 20", temp: 28, customers: 189 },
];

const orderTypePie = [
  { name: "Individual", value: 52, color: C.cyan },
  { name: "Family (2–4)", value: 33, color: C.green },
  { name: "Group (5+)", value: 15, color: C.yellow },
];

const weeklyRows = [
  { day: "Monday",    date: "Jun 16", conditions: "Overcast, 21°C",   covers: 130, lastWeek: 118, peak: "1:00 pm", indiv: 60, family: 30, group: 10, topItem: "Pasta Carbonara",  forecast: false },
  { day: "Tuesday",   date: "Jun 17", conditions: "Rain, 18°C",       covers: 95,  lastWeek: 104, peak: "7:00 pm", indiv: 58, family: 35, group: 7,  topItem: "Ribollita Soup",   forecast: false },
  { day: "Wednesday", date: "Jun 18", conditions: "Rain, 17°C",       covers: 91,  lastWeek: 145, peak: "12:00 pm",indiv: 72, family: 20, group: 8,  topItem: "Ribollita Soup",   forecast: false },
  { day: "Thursday",  date: "Jun 19", conditions: "Partly cloudy, 23°C", covers: 155, lastWeek: 131, peak: "8:00 pm", indiv: 60, family: 30, group: 10, topItem: "Margherita Pizza", forecast: false },
  { day: "Friday",    date: "Jun 20", conditions: "Sunny, 25°C",      covers: 189, lastWeek: 160, peak: "8:00 pm", indiv: 55, family: 25, group: 20, topItem: "Ribeye Steak",     forecast: false },
  { day: "Saturday",  date: "Jun 21", conditions: "Sunny, 26°C (forecast)", covers: 0, lastWeek: 185, peak: "—",     indiv: 0,  family: 0,  group: 0,  topItem: "—",                forecast: true },
  { day: "Sunday",    date: "Jun 22", conditions: "Sunny, 27°C (forecast)", covers: 0, lastWeek: 198, peak: "—",     indiv: 0,  family: 0,  group: 0,  topItem: "—",                forecast: true },
];

const aiNarratives = [
  {
    section: "Overall Performance",
    body: "This week is tracking 8.3% above the same period last week, with 820 confirmed covers across Mon–Fri. Friday marked the strongest single day at 189 covers, driven by group bookings and warm-weather dining. Wednesday's rainfall was the primary drag, bringing covers 37% below the Monday baseline. The weekend forecast (Sat–Sun) is favourable and is projected to push weekly totals to approximately 1,220 covers.",
  },
  {
    section: "Customer Behaviour Patterns",
    body: "Individual diners dominated midweek (Mon–Thu at 58–72%), a pattern consistent with business lunches and solo working hours. Friday saw a marked shift toward group bookings (20%), which correlates with pre-weekend social dining. Saturday–Sunday are forecast to revert to family-dominant traffic (50–58%), in line with the trailing 4-week average. Menu recommendations: family-shareable portions and set menus perform significantly better on weekend slots.",
  },
  {
    section: "Weather & Sales Correlation",
    body: "Tuesday–Wednesday rainfall caused a combined 25% decline in total covers versus last week's equivalent days. On rain days, hot dish orders (soups, risotto, braised meats) increased by an estimated 38–42%. Basil and tomato stock burn rates slowed considerably mid-week, contributing to the current overstock condition. For every 5°C drop below 20°C, foot traffic is reduced by approximately 12%, based on the past 4 weeks of data.",
  },
  {
    section: "Stock Implications for Next Week",
    body: "Given the uptick in group bookings on Friday and the projected sunny weekend, Ribeye Steak and Mozzarella di Bufala are flagged for increased ordering. Fresh Basil remains at overstock risk — the rain-induced slowdown prevented expected throughput. Tomato burn rate is expected to recover Saturday–Sunday if cover projections hold. Recommend activating the Caprese Salad discount initiative immediately to reduce basil spoilage before Monday.",
  },
];

type ActionStatus = "pending" | "in_progress" | "done";

interface ActionItem {
  id: string;
  source: string;
  priority: "high" | "medium" | "low";
  icon: "rain" | "cart";
  title: string;
  detail: string;
  timing: string;
}

const actionPlan: ActionItem[] = [
  // From: Overall Performance
  {
    id: "a1",
    source: "Overall Performance",
    priority: "high",
    icon: "cart",
    title: "Increase Ribeye Steak order: 6 kg → 8 kg next week",
    detail: "Friday's 189-cover peak made Ribeye the top-selling item. Weekend covers are projected at ~210 (Sat) and ~215 (Sun). Current 6 kg stock will be depleted by Saturday dinner. Order an additional 2 kg to avoid mid-service stockout.",
    timing: "Place order by Thursday, Jun 19",
  },
  {
    id: "a2",
    source: "Overall Performance",
    priority: "medium",
    icon: "cart",
    title: "Increase Mascarpone order: 4 kg → 6 kg next week",
    detail: "Tiramisu demand is stable at roughly 3 portions per table on weekend nights. A projected 210 Sat covers with 52% family seating means Tiramisu will likely outsell Mon–Fri by 3×. Current 4 kg stock may fall short of weekend demand.",
    timing: "Add to Thursday order",
  },
  // From: Customer Behaviour Patterns
  {
    id: "a3",
    source: "Customer Behaviour Patterns",
    priority: "high",
    icon: "cart",
    title: "Proof 20 extra pizza dough balls Friday morning",
    detail: "Family diners (52–58% of Sat–Sun covers) order pizza at a significantly higher rate than midweek individual diners. Current stock of 62 balls is projected to fall below threshold by Saturday 7pm. Proof 20 additional balls on Friday morning for a total buffer of 82.",
    timing: "Friday, Jun 21 — morning",
  },
  {
    id: "a4",
    source: "Customer Behaviour Patterns",
    priority: "high",
    icon: "cart",
    title: "Pre-portion 15 Tiramisu servings Friday afternoon",
    detail: "Tiramisu benefits from a 24–48 hr rest period. Pre-making 15 individual portions on Friday afternoon uses current Mascarpone stock efficiently, improves dish consistency, and reduces in-service kitchen load during Saturday peak. Estimated Mascarpone use: 1.5 kg.",
    timing: "Friday, Jun 21 — afternoon",
  },
  {
    id: "a5",
    source: "Customer Behaviour Patterns",
    priority: "medium",
    icon: "cart",
    title: "Pre-portion Mozzarella into family-size serves (200 g) before Saturday",
    detail: "3 kg of excess Mozzarella di Bufala expires in 4 days. Pre-portioning into 200 g family-serve packs for Caprese eliminates in-service cutting waste (estimated 8–12% trim loss) and yields approximately 14–15 ready-to-plate portions for weekend service.",
    timing: "Friday, Jun 21 — prep",
  },
  // From: Weather & Sales Correlation
  {
    id: "a6",
    source: "Weather & Sales Correlation",
    priority: "high",
    icon: "rain",
    title: "Batch-cook tomato surplus into passata — freeze 5 kg",
    detail: "9 kg tomato excess is at spoilage risk within 2 days. Cooking down into passata removes all immediate spoilage risk. Yield: approximately 5 kg passata from 9 kg fresh. Freeze in 500 g portions for use in Arrabbiata, pizza base, and soup base over the next 3 months.",
    timing: "Today / tomorrow — kitchen task",
  },
  {
    id: "a7",
    source: "Weather & Sales Correlation",
    priority: "high",
    icon: "rain",
    title: "Process excess basil into pesto — extends shelf life by 7 days",
    detail: "2.7 kg excess Fresh Basil expires tomorrow. Blending with Olive Oil (600 ml from current stock) and Pecorino Romano converts it into pesto with an 8-day refrigerated shelf life. Estimated yield: ~2.2 kg pesto. Usable in Pesto Pasta, bruschetta spread, and pizza bianca base.",
    timing: "Today — immediate kitchen task",
  },
  {
    id: "a8",
    source: "Weather & Sales Correlation",
    priority: "medium",
    icon: "rain",
    title: "Rain-day stock protocol: cut fresh salad prep by 30%, redirect to hot prep",
    detail: "On any morning with rain forecast, reduce fresh tomato and herb prep quantities by 30% and redirect those portions to Ribollita Soup base and tomato bruschetta instead of cold Caprese and salad. This prevents end-of-day waste from slow cold-dish turnover and absorbs surplus fresh stock into high-demand hot dishes.",
    timing: "Set as standing kitchen protocol",
  },
  // From: Stock Implications
  {
    id: "a9",
    source: "Stock Implications for Next Week",
    priority: "high",
    icon: "cart",
    title: "Reduce San Marzano Tomato order by 30% next week",
    detail: "Standard weekly order is approximately 9 kg. Current overstock of 9 kg excess (18 kg on hand) combined with the passata batch will carry ~5 kg of usable tomato product into next week. Order 6 kg instead of 9 kg to avoid compounding the overstock into a second week.",
    timing: "Adjust next order cycle",
  },
  {
    id: "a10",
    source: "Stock Implications for Next Week",
    priority: "medium",
    icon: "cart",
    title: "Skip Fresh Basil and Olive Oil orders this week",
    detail: "Pesto batch will consume the basil surplus and produce 2.2 kg usable pesto — do not reorder basil until next week (max 3 kg). Olive Oil stock is 12 L against 8 L average weekly use; skip this week's order entirely. Combined saving: estimated €28–34 in unnecessary procurement.",
    timing: "This week — skip both",
  },
];

const stockInputDefaults: Record<string, string> = {
  "San Marzano Tomatoes": "18 kg",
  "Fresh Basil": "4.2 kg",
  "Mozzarella di Bufala": "8 kg",
  "Pizza Dough Balls": "62 units",
  "Pancetta": "3 kg",
  "Ribeye Steak": "6 kg",
  "Mascarpone": "4 kg",
  "Olive Oil": "12 L",
};

const DarkTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="rounded-xl p-3" style={{ background: "#252D36", border: `1px solid ${C.border}` }}>
        <p className="text-xs mb-1.5" style={{ color: C.muted, fontWeight: 600 }}>{label}</p>
        {payload.map((p: any) => (
          <p key={p.dataKey} className="text-xs" style={{ color: p.color ?? C.text, fontWeight: 600 }}>
            {p.name}: {p.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

const actionIcon = (icon: ActionItem["icon"]) => {
  if (icon === "rain") return <CloudRain className="w-4 h-4" />;
  return <ShoppingCart className="w-4 h-4" />;
};

const priorityConfig = {
  high:   { label: "High",   color: "#FF6B6B" },
  medium: { label: "Medium", color: C.yellow   },
  low:    { label: "Low",    color: C.muted    },
} as const;

export function AnalyticsView() {
  const [showStocks, setShowStocks] = useState(false);
  const [stocks, setStocks] = useState(stockInputDefaults);
  const [editingStock, setEditingStock] = useState<string | null>(null);
  const [tempStockVal, setTempStockVal] = useState("");
  const [actionStatuses, setActionStatuses] = useState<Record<string, ActionStatus>>(
    Object.fromEntries(actionPlan.map((a) => [a.id, "pending" as ActionStatus]))
  );
  const [expandedAction, setExpandedAction] = useState<string | null>(null);

  const cycleStatus = (id: string) => {
    setActionStatuses((prev) => {
      const next: Record<ActionStatus, ActionStatus> = { pending: "in_progress", in_progress: "done", done: "pending" };
      return { ...prev, [id]: next[prev[id]] };
    });
  };

  const confirmedCovers = weeklyRows.filter((r) => !r.forecast).reduce((s, r) => s + r.covers, 0);
  const lastWeekTotal = weeklyRows.filter((r) => !r.forecast).reduce((s, r) => s + r.lastWeek, 0);
  const pctVsLW = (((confirmedCovers - lastWeekTotal) / lastWeekTotal) * 100).toFixed(1);
  const bestDay = [...weeklyRows].filter((r) => !r.forecast).sort((a, b) => b.covers - a.covers)[0];
  const avgDaily = Math.round(confirmedCovers / weeklyRows.filter((r) => !r.forecast).length);

  const exportStocksCSV = () => {
    const header = ["Ingredient", "Current Stock"];
    const rows = Object.entries(stocks).map(([k, v]) => [k, v]);
    const csv = [header, ...rows].map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `current-stocks-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 overflow-y-auto" style={{ background: C.bg }}>
      <div className="sticky top-0 z-10 px-7 py-4" style={{ background: C.bg, borderBottom: `1px solid ${C.border}` }}>
        <h2 style={{ color: C.text, fontSize: "1.25rem", fontWeight: 700 }}>Analytics & Trends</h2>
        <p className="text-sm" style={{ color: C.muted }}>Weekly performance · Chart data · Customer behaviour</p>
      </div>

      <div className="p-7 space-y-5">

        {/* Row 1: This Week vs Last + Pie */}
        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2 rounded-2xl p-5" style={{ background: C.card, border: `1px solid ${C.border}` }}>
            <div className="flex items-center justify-between mb-1">
              <p style={{ color: C.text, fontWeight: 600, fontSize: "0.9rem" }}>Covers: This Week vs Last Week</p>
              <div className="flex gap-3 text-xs">
                <span style={{ color: C.cyan }}>● This week</span>
                <span style={{ color: C.dim }}>● Last week</span>
              </div>
            </div>
            <p className="text-xs mb-4" style={{ color: C.muted }}>Daily customer covers comparison</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={thisWeekData} margin={{ top: 0, right: 0, left: -25, bottom: 0 }} barGap={3}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: C.muted }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 9, fill: C.muted }} tickLine={false} axisLine={false} />
                <Tooltip content={<DarkTooltip />} cursor={{ fill: "rgba(255,255,255,0.02)" }} />
                <Bar dataKey="thisWeek" name="This Week" fill={C.cyan} radius={[4, 4, 0, 0]} fillOpacity={0.85} />
                <Bar dataKey="lastWeek" name="Last Week" fill="rgba(255,255,255,0.14)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="rounded-2xl p-5" style={{ background: C.card, border: `1px solid ${C.border}` }}>
            <p style={{ color: C.text, fontWeight: 600, fontSize: "0.9rem" }}>Order Type Mix</p>
            <p className="text-xs mb-3" style={{ color: C.muted }}>Weekly avg by party size</p>
            <div className="flex justify-center">
              <PieChart width={150} height={150}>
                <Pie data={orderTypePie} cx={70} cy={70} innerRadius={40} outerRadius={62} paddingAngle={3} dataKey="value">
                  {orderTypePie.map((e, i) => <Cell key={`c-${i}`} fill={e.color} fillOpacity={0.85} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "#252D36", border: `1px solid ${C.border}`, borderRadius: "10px", fontSize: "11px" }} />
              </PieChart>
            </div>
            <div className="space-y-2">
              {orderTypePie.map((d) => (
                <div key={d.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full" style={{ background: d.color }} />
                    <span className="text-xs" style={{ color: C.muted }}>{d.name}</span>
                  </div>
                  <span className="text-xs" style={{ color: d.color, fontWeight: 700 }}>{d.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Row 2: Peak Hours + Customer Type */}
        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-2xl p-5" style={{ background: C.card, border: `1px solid ${C.border}` }}>
            <p style={{ color: C.text, fontWeight: 600, fontSize: "0.9rem" }}>Peak Hours Analysis</p>
            <p className="text-xs mb-4" style={{ color: C.muted }}>Order volume by hour — weekly average</p>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={peakHoursData} margin={{ top: 0, right: 0, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} vertical={false} />
                <XAxis dataKey="hour" tick={{ fontSize: 9, fill: C.muted }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 9, fill: C.muted }} tickLine={false} axisLine={false} />
                <Tooltip content={<DarkTooltip />} cursor={{ fill: "rgba(255,255,255,0.02)" }} />
                <Bar dataKey="orders" name="Orders" fill={C.green} radius={[3, 3, 0, 0]} fillOpacity={0.85} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="rounded-2xl p-5" style={{ background: C.card, border: `1px solid ${C.border}` }}>
            <p style={{ color: C.text, fontWeight: 600, fontSize: "0.9rem" }}>Customer Type by Day</p>
            <p className="text-xs mb-4" style={{ color: C.muted }}>Family / Individual / Group breakdown (%)</p>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={customerTypeData} margin={{ top: 0, right: 0, left: -25, bottom: 0 }} barCategoryGap="30%">
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 9, fill: C.muted }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 9, fill: C.muted }} tickLine={false} axisLine={false} tickFormatter={(v) => `${v}%`} />
                <Tooltip content={<DarkTooltip />} cursor={{ fill: "rgba(255,255,255,0.02)" }} />
                <Bar dataKey="family" name="Family" stackId="a" fill={C.green} fillOpacity={0.8} />
                <Bar dataKey="individual" name="Individual" stackId="a" fill={C.cyan} fillOpacity={0.7} />
                <Bar dataKey="group" name="Group (5+)" stackId="a" fill={C.yellow} fillOpacity={0.8} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Row 3: Weather */}
        <div className="rounded-2xl p-5" style={{ background: C.card, border: `1px solid ${C.border}` }}>
          <div className="flex items-center gap-2 mb-1">
            <Thermometer className="w-4 h-4" style={{ color: C.yellow }} />
            <p style={{ color: C.text, fontWeight: 600, fontSize: "0.9rem" }}>Temperature vs. Customer Volume</p>
          </div>
          <p className="text-xs mb-4" style={{ color: C.muted }}>12-day rolling view — warmer weather correlates with higher covers</p>
          <ResponsiveContainer width="100%" height={170}>
            <LineChart data={weatherSalesData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
              <XAxis dataKey="day" tick={{ fontSize: 9, fill: C.muted }} tickLine={false} axisLine={false} />
              <YAxis yAxisId="l" tick={{ fontSize: 9, fill: C.muted }} tickLine={false} axisLine={false} />
              <YAxis yAxisId="r" orientation="right" tick={{ fontSize: 9, fill: C.muted }} tickLine={false} axisLine={false} tickFormatter={(v) => `${v}°`} />
              <Tooltip content={<DarkTooltip />} />
              <Line yAxisId="l" type="monotone" dataKey="customers" name="Customers" stroke={C.cyan} strokeWidth={2.5} dot={{ r: 3, fill: C.cyan }} />
              <Line yAxisId="r" type="monotone" dataKey="temp" name="Temp (°C)" stroke={C.yellow} strokeWidth={2} strokeDasharray="5 3" dot={{ r: 2, fill: C.yellow }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* ─── Weekly Business Recap ────────────────────────────────────── */}
        <div className="rounded-2xl overflow-hidden" style={{ background: C.card, border: `1px solid ${C.border}` }}>
          {/* Header */}
          <div className="px-6 py-5 flex items-center justify-between" style={{ borderBottom: `1px solid ${C.border}` }}>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "rgba(91,238,252,0.1)" }}>
                <Brain className="w-4 h-4" style={{ color: C.cyan }} />
              </div>
              <div>
                <p style={{ color: C.text, fontWeight: 700, fontSize: "0.95rem" }}>Weekly Business Recap</p>
                <p className="text-xs" style={{ color: C.muted }}>AI-generated analysis · Week of June 16–22, 2026</p>
              </div>
            </div>
            <span className="px-3 py-1 rounded-md text-xs" style={{ background: "rgba(255,255,255,0.05)", color: C.dim, fontWeight: 500 }}>
              Updated 2h ago
            </span>
          </div>

          {/* Summary KPIs */}
          <div className="grid grid-cols-4 divide-x" style={{ borderBottom: `1px solid ${C.border}`, divideColor: C.border }}>
            {[
              { label: "Confirmed Covers", value: confirmedCovers.toLocaleString(), note: "Mon–Fri" },
              {
                label: "vs. Last Week",
                value: `${Number(pctVsLW) >= 0 ? "+" : ""}${pctVsLW}%`,
                note: "same days LW",
                color: Number(pctVsLW) >= 0 ? C.green : "#FF6B6B",
              },
              { label: "Daily Average", value: avgDaily.toString(), note: "confirmed days" },
              { label: "Peak Day", value: bestDay.day.slice(0, 3), note: `${bestDay.covers} covers`, color: C.cyan },
            ].map((s, i) => (
              <div key={i} className="px-5 py-4" style={{ borderRight: i < 3 ? `1px solid ${C.border}` : "none" }}>
                <p className="text-xs uppercase tracking-wide mb-1" style={{ color: C.dim, fontWeight: 600 }}>{s.label}</p>
                <p style={{ color: s.color ?? C.text, fontSize: "1.4rem", fontWeight: 700, lineHeight: 1.1 }}>{s.value}</p>
                <p className="text-xs mt-0.5" style={{ color: C.dim }}>{s.note}</p>
              </div>
            ))}
          </div>

          {/* Day-by-day table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                  {["Day", "Date", "Conditions", "Covers", "vs LW", "Peak Hour", "Customer Mix", "Top Item"].map((h) => (
                    <th key={h} className="px-5 py-3 text-left text-xs uppercase tracking-wide whitespace-nowrap" style={{ color: C.dim, fontWeight: 600, background: "rgba(255,255,255,0.02)" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {weeklyRows.map((row) => {
                  const delta = row.covers > 0 ? ((row.covers - row.lastWeek) / row.lastWeek * 100) : null;
                  const isUp = delta !== null && delta >= 0;
                  return (
                    <tr key={row.day} style={{ borderBottom: `1px solid rgba(255,255,255,0.03)`, opacity: row.forecast ? 0.5 : 1 }}>
                      <td className="px-5 py-3.5">
                        <span className="text-sm" style={{ color: C.text, fontWeight: 600 }}>{row.day}</span>
                        {row.forecast && (
                          <span className="ml-2 text-xs px-1.5 py-0.5 rounded" style={{ background: "rgba(255,255,255,0.06)", color: C.dim, fontWeight: 500 }}>forecast</span>
                        )}
                      </td>
                      <td className="px-5 py-3.5 text-sm whitespace-nowrap" style={{ color: C.muted }}>{row.date}</td>
                      <td className="px-5 py-3.5 text-sm whitespace-nowrap" style={{ color: C.muted }}>{row.conditions}</td>
                      <td className="px-5 py-3.5">
                        <span className="text-sm" style={{ color: row.covers > 0 ? C.text : C.dim, fontWeight: row.covers > 0 ? 700 : 400 }}>
                          {row.covers > 0 ? row.covers : "—"}
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        {delta !== null ? (
                          <span className="flex items-center gap-0.5 text-xs whitespace-nowrap" style={{ color: isUp ? C.green : "#FF6B6B", fontWeight: 700 }}>
                            {isUp ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                            {Math.abs(delta).toFixed(1)}%
                          </span>
                        ) : (
                          <span style={{ color: C.dim }}>—</span>
                        )}
                      </td>
                      <td className="px-5 py-3.5 text-sm" style={{ color: C.muted }}>{row.peak}</td>
                      <td className="px-5 py-3.5">
                        {row.covers > 0 ? (
                          <span className="text-xs" style={{ color: C.muted }}>
                            <span style={{ color: C.cyan }}>{row.indiv}%</span> ind ·{" "}
                            <span style={{ color: C.green }}>{row.family}%</span> fam ·{" "}
                            <span style={{ color: C.yellow }}>{row.group}%</span> grp
                          </span>
                        ) : <span style={{ color: C.dim }}>—</span>}
                      </td>
                      <td className="px-5 py-3.5 text-sm" style={{ color: row.topItem === "—" ? C.dim : C.muted }}>{row.topItem}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* AI Narrative */}
          <div className="px-6 py-5 space-y-5" style={{ borderTop: `1px solid ${C.border}` }}>
            <p className="text-xs uppercase tracking-widest" style={{ color: C.dim, fontWeight: 600 }}>AI Analysis</p>
            <div className="grid grid-cols-2 gap-5">
              {aiNarratives.map((n) => (
                <div key={n.section}>
                  <p className="text-sm mb-2" style={{ color: C.text, fontWeight: 600 }}>{n.section}</p>
                  <p className="text-sm leading-relaxed" style={{ color: C.muted }}>{n.body}</p>
                </div>
              ))}
            </div>
          </div>

          {/* ── Action Plan ─────────────────────────────────────────────── */}
          <div style={{ borderTop: `1px solid ${C.border}` }}>
            {/* Section header */}
            <div className="px-6 py-4 flex items-center justify-between" style={{ borderBottom: `1px solid ${C.border}` }}>
              <div>
                <p className="text-xs uppercase tracking-widest mb-0.5" style={{ color: C.dim, fontWeight: 600 }}>Recommended Actions</p>
                <p className="text-sm" style={{ color: C.text, fontWeight: 600 }}>
                  {actionPlan.length} solutions derived from AI analysis
                </p>
              </div>
              <div className="flex items-center gap-4 text-xs" style={{ color: C.dim }}>
                {(["pending", "in_progress", "done"] as ActionStatus[]).map((s) => {
                  const count = Object.values(actionStatuses).filter((v) => v === s).length;
                  const labels: Record<ActionStatus, string> = { pending: "Pending", in_progress: "In Progress", done: "Done" };
                  const colors: Record<ActionStatus, string> = { pending: C.dim, in_progress: C.yellow, done: C.green };
                  return (
                    <span key={s} style={{ color: colors[s] }}>
                      {count} {labels[s]}
                    </span>
                  );
                })}
              </div>
            </div>

            {/* Group by source narrative */}
            {aiNarratives.map((narrative) => {
              const items = actionPlan.filter((a) => a.source === narrative.section);
              return (
                <div key={narrative.section} style={{ borderBottom: `1px solid ${C.border}` }}>
                  {/* Group label */}
                  <div className="px-6 py-3 flex items-center gap-2" style={{ background: "rgba(255,255,255,0.015)" }}>
                    <span className="text-xs uppercase tracking-wide" style={{ color: C.dim, fontWeight: 600 }}>
                      From: {narrative.section}
                    </span>
                    <span className="text-xs" style={{ color: C.dim }}>·</span>
                    <span className="text-xs" style={{ color: C.dim }}>{items.length} actions</span>
                  </div>

                  {/* Actions */}
                  <div>
                    {items.map((action, idx) => {
                      const status = actionStatuses[action.id];
                      const pri = priorityConfig[action.priority];
                      const isExpanded = expandedAction === action.id;
                      const isDone = status === "done";

                      return (
                        <div key={action.id} style={{
                          borderTop: idx > 0 ? `1px solid rgba(255,255,255,0.03)` : "none",
                          opacity: isDone ? 0.55 : 1,
                          transition: "opacity 0.2s",
                        }}>
                          {/* Main row */}
                          <div className="flex items-center gap-4 px-6 py-3.5">
                            {/* Status toggle */}
                            <button
                              onClick={() => cycleStatus(action.id)}
                              className="w-5 h-5 rounded flex items-center justify-center shrink-0 transition-all"
                              style={{
                                background: isDone ? `${C.green}20` : status === "in_progress" ? `${C.yellow}15` : "rgba(255,255,255,0.05)",
                                border: `1.5px solid ${isDone ? C.green : status === "in_progress" ? C.yellow : "rgba(255,255,255,0.15)"}`,
                              }}
                            >
                              {isDone && <Check className="w-3 h-3" style={{ color: C.green }} />}
                              {status === "in_progress" && <div className="w-2 h-2 rounded-full" style={{ background: C.yellow }} />}
                            </button>

                            {/* Icon */}
                            <span style={{ color: isDone ? C.dim : C.muted }}>{actionIcon(action.icon)}</span>

                            {/* Title + timing */}
                            <div className="flex-1 min-w-0">
                              <p className="text-sm" style={{ color: isDone ? C.dim : C.text, fontWeight: 500, textDecoration: isDone ? "line-through" : "none" }}>
                                {action.title}
                              </p>
                              <p className="text-xs mt-0.5" style={{ color: C.dim }}>{action.timing}</p>
                            </div>

                            {/* Priority */}
                            <span className="text-xs shrink-0" style={{ color: pri.color, fontWeight: 600 }}>
                              {pri.label}
                            </span>

                            {/* Status label */}
                            <span className="text-xs w-20 text-right shrink-0" style={{
                              color: isDone ? C.green : status === "in_progress" ? C.yellow : C.dim,
                              fontWeight: status !== "pending" ? 600 : 400,
                            }}>
                              {status === "in_progress" ? "In progress" : status === "done" ? "Done" : "Pending"}
                            </span>

                            {/* Expand toggle */}
                            <button
                              onClick={() => setExpandedAction(isExpanded ? null : action.id)}
                              className="shrink-0 transition-colors"
                              style={{ background: "none", border: "none", color: C.dim }}
                            >
                              {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                            </button>
                          </div>

                          {/* Expanded detail */}
                          {isExpanded && (
                            <div className="px-6 pb-4" style={{ borderTop: `1px solid rgba(255,255,255,0.04)` }}>
                              <p className="text-sm leading-relaxed pt-3" style={{ color: C.muted }}>{action.detail}</p>
                              <div className="flex items-center gap-3 mt-3">
                                {status !== "done" && (
                                  <button
                                    onClick={() => cycleStatus(action.id)}
                                    className="px-4 py-1.5 rounded-lg text-xs transition-all hover:opacity-90"
                                    style={{
                                      background: status === "pending" ? "rgba(91,238,252,0.1)" : `${C.green}18`,
                                      border: `1px solid ${status === "pending" ? "rgba(91,238,252,0.25)" : `${C.green}40`}`,
                                      color: status === "pending" ? C.cyan : C.green,
                                      fontWeight: 600,
                                    }}
                                  >
                                    {status === "pending" ? "Mark as In Progress" : "Mark as Done"}
                                  </button>
                                )}
                                {status === "done" && (
                                  <button
                                    onClick={() => cycleStatus(action.id)}
                                    className="px-4 py-1.5 rounded-lg text-xs transition-colors"
                                    style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${C.border}`, color: C.dim }}
                                  >
                                    Reopen
                                  </button>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

        </div>

        {/* ─── Current Stock Levels ────────────────────────────────────── */}
        <div className="rounded-2xl overflow-hidden" style={{ background: C.card, border: `1px solid ${C.border}` }}>
          <button onClick={() => setShowStocks(!showStocks)}
            className="w-full flex items-center gap-3 px-5 py-4 text-left"
            style={{ background: "none", border: "none" }}>
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "rgba(238,230,56,0.08)" }}>
              <Package className="w-4 h-4" style={{ color: C.yellow }} />
            </div>
            <div className="flex-1">
              <p style={{ color: C.text, fontWeight: 600, fontSize: "0.9rem" }}>Current Stock Levels</p>
              <p className="text-xs" style={{ color: C.muted }}>LLM context · Edit values to improve AI insight accuracy · Exportable</p>
            </div>
            {showStocks ? <ChevronUp className="w-4 h-4" style={{ color: C.muted }} /> : <ChevronDown className="w-4 h-4" style={{ color: C.muted }} />}
          </button>

          {showStocks && (
            <div style={{ borderTop: `1px solid ${C.border}` }}>
              {/* Export button row */}
              <div className="flex items-center justify-between px-5 py-3" style={{ borderBottom: `1px solid ${C.border}` }}>
                <p className="text-xs" style={{ color: C.dim }}>
                  {Object.keys(stocks).length} ingredients tracked · Click any value to edit
                </p>
                <button onClick={exportStocksCSV}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-all hover:opacity-90"
                  style={{ background: "rgba(91,238,252,0.1)", border: `1px solid rgba(91,238,252,0.25)`, color: C.cyan, fontWeight: 600 }}>
                  <Download className="w-3.5 h-3.5" />
                  Export Stock CSV
                </button>
              </div>

              {/* Stock table */}
              <table className="w-full">
                <thead>
                  <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                    <th className="px-5 py-2.5 text-left text-xs uppercase tracking-wide" style={{ color: C.dim, fontWeight: 600 }}>Ingredient</th>
                    <th className="px-5 py-2.5 text-left text-xs uppercase tracking-wide" style={{ color: C.dim, fontWeight: 600 }}>Current Stock</th>
                    <th className="px-5 py-2.5 text-left text-xs uppercase tracking-wide" style={{ color: C.dim, fontWeight: 600 }}>AI Efficiency Signal</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(stocks).map(([ingredient, value], idx) => {
                    const signals: Record<string, { label: string; color: string }> = {
                      "San Marzano Tomatoes": { label: "Overstock — reduce next order", color: "#FF6B6B" },
                      "Fresh Basil": { label: "Critical overstock — spoiling soon", color: "#FF6B6B" },
                      "Mozzarella di Bufala": { label: "Slight overstock — monitor", color: C.yellow },
                      "Pizza Dough Balls": { label: "Slight overstock — weekend may clear", color: C.yellow },
                      "Pancetta": { label: "Optimal — no action needed", color: C.green },
                      "Ribeye Steak": { label: "Low — consider increasing order", color: C.cyan },
                      "Mascarpone": { label: "Optimal — no action needed", color: C.green },
                      "Olive Oil": { label: "Sufficient — skip this week", color: C.muted },
                    };
                    const sig = signals[ingredient];
                    return (
                      <tr key={ingredient} style={{ borderBottom: idx < Object.keys(stocks).length - 1 ? `1px solid rgba(255,255,255,0.03)` : "none" }}>
                        <td className="px-5 py-3 text-sm" style={{ color: C.text, fontWeight: 500 }}>{ingredient}</td>
                        <td className="px-5 py-3">
                          {editingStock === ingredient ? (
                            <div className="flex items-center gap-1.5">
                              <input autoFocus value={tempStockVal} onChange={(e) => setTempStockVal(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === "Enter") { setStocks((p) => ({ ...p, [ingredient]: tempStockVal })); setEditingStock(null); }
                                  if (e.key === "Escape") setEditingStock(null);
                                }}
                                className="w-24 px-2 py-1 rounded-lg text-sm outline-none"
                                style={{ background: C.card2, border: `1px solid ${C.cyan}`, color: C.text, fontWeight: 600 }} />
                              <button onClick={() => { setStocks((p) => ({ ...p, [ingredient]: tempStockVal })); setEditingStock(null); }}
                                style={{ background: "none", border: "none" }}><Check className="w-3.5 h-3.5" style={{ color: C.green }} /></button>
                              <button onClick={() => setEditingStock(null)} style={{ background: "none", border: "none" }}><X className="w-3.5 h-3.5" style={{ color: C.muted }} /></button>
                            </div>
                          ) : (
                            <button onClick={() => { setEditingStock(ingredient); setTempStockVal(value); }}
                              className="flex items-center gap-1.5 group"
                              style={{ background: "none", border: "none" }}>
                              <span className="text-sm" style={{ color: C.cyan, fontWeight: 700 }}>{value}</span>
                              <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: C.cyan }} />
                            </button>
                          )}
                        </td>
                        <td className="px-5 py-3">
                          {sig && <span className="text-xs" style={{ color: sig.color }}>{sig.label}</span>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
