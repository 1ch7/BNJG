import { useState } from "react";
import { UploadCloud, CheckCircle, TrendingUp, Package, Minus, Plus, Download, Edit3, Check, X } from "lucide-react";

const C = {
  bg: "#151A1F", card: "#1A2027", card2: "#1F2831", border: "rgba(255,255,255,0.07)",
  cyan: "#5BEEFC", green: "#16F686", yellow: "#EEE638",
  text: "#FFFFFF", muted: "rgba(255,255,255,0.5)", dim: "rgba(255,255,255,0.25)",
};

type DayStatus = "uploaded" | "pending" | "future";

const initialWeekDays: { label: string; short: string; status: DayStatus }[] = [
  { label: "Monday", short: "Mon", status: "uploaded" },
  { label: "Tuesday", short: "Tue", status: "uploaded" },
  { label: "Wednesday", short: "Wed", status: "uploaded" },
  { label: "Thursday", short: "Thu", status: "uploaded" },
  { label: "Friday", short: "Fri", status: "pending" },
  { label: "Saturday", short: "Sat", status: "future" },
  { label: "Sunday", short: "Sun", status: "future" },
];

const stockSuggestions = [
  { ingredient: "San Marzano Tomatoes", unit: "kg", currentStock: 18, aiAvgUsage: 12, aiSuggested: 8, reason: "Overstock detected — reduce order" },
  { ingredient: "Fresh Basil", unit: "bunch", currentStock: 4, aiAvgUsage: 9, aiSuggested: 6, reason: "Trending +20% in pasta orders" },
  { ingredient: "Pizza Dough Balls", unit: "units", currentStock: 40, aiAvgUsage: 55, aiSuggested: 20, reason: "Weekend peak expected" },
  { ingredient: "Mozzarella di Bufala", unit: "kg", currentStock: 8, aiAvgUsage: 10, aiSuggested: 5, reason: "Normal restock" },
  { ingredient: "Extra Virgin Olive Oil", unit: "L", currentStock: 12, aiAvgUsage: 8, aiSuggested: 0, reason: "Sufficient stock — skip order" },
  { ingredient: "Pancetta", unit: "kg", currentStock: 3, aiAvgUsage: 5, aiSuggested: 4, reason: "Carbonara trending this week" },
  { ingredient: "Pecorino Romano", unit: "kg", currentStock: 2, aiAvgUsage: 3, aiSuggested: 3, reason: "Low stock alert" },
  { ingredient: "Ribeye Steak", unit: "kg", currentStock: 6, aiAvgUsage: 8, aiSuggested: 5, reason: "Weekend dinner boost expected" },
  { ingredient: "Mascarpone", unit: "kg", currentStock: 4, aiAvgUsage: 3, aiSuggested: 2, reason: "Tiramisu demand stable" },
  { ingredient: "Garlic", unit: "kg", currentStock: 2, aiAvgUsage: 3, aiSuggested: 2, reason: "Standard weekly restock" },
];

export function DailySalesView() {
  const [days, setDays] = useState(initialWeekDays);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadingDay, setUploadingDay] = useState<string | null>(null);

  const [quantities, setQuantities] = useState<Record<string, number>>(
    Object.fromEntries(stockSuggestions.map((s) => [s.ingredient, s.aiSuggested]))
  );
  const [avgUsage, setAvgUsage] = useState<Record<string, number>>(
    Object.fromEntries(stockSuggestions.map((s) => [s.ingredient, s.aiAvgUsage]))
  );
  const [editingQty, setEditingQty] = useState<string | null>(null);
  const [editingAvg, setEditingAvg] = useState<string | null>(null);
  const [tempVal, setTempVal] = useState("");

  const uploadedCount = days.filter((d) => d.status === "uploaded").length;

  const simulateUpload = () => {
    const firstPending = days.findIndex((d) => d.status === "pending");
    if (firstPending === -1) return;
    const dayLabel = days[firstPending].label;
    setUploadingDay(dayLabel);
    setTimeout(() => {
      setDays((prev) => prev.map((d, i) => (i === firstPending ? { ...d, status: "uploaded" as DayStatus } : d)));
      setUploadingDay(null);
    }, 1200);
  };

  const adjustQty = (ing: string, delta: number) =>
    setQuantities((prev) => ({ ...prev, [ing]: Math.max(0, (prev[ing] ?? 0) + delta) }));

  const commitEdit = (field: "qty" | "avg", ing: string) => {
    const num = parseFloat(tempVal);
    if (!isNaN(num) && num >= 0) {
      if (field === "qty") setQuantities((p) => ({ ...p, [ing]: num }));
      else setAvgUsage((p) => ({ ...p, [ing]: num }));
    }
    setEditingQty(null);
    setEditingAvg(null);
    setTempVal("");
  };

  const exportCSV = () => {
    const header = ["Ingredient", "Unit", "Current Stock", "Avg Weekly Use", "Order Qty", "AI Reasoning"];
    const rows = stockSuggestions.map((row) => [
      row.ingredient,
      row.unit,
      row.currentStock,
      avgUsage[row.ingredient] ?? row.aiAvgUsage,
      quantities[row.ingredient] ?? row.aiSuggested,
      `"${row.reason}"`,
    ]);
    const csv = [header, ...rows].map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `stock-order-week-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 overflow-y-auto" style={{ background: C.bg }}>
      <div className="sticky top-0 z-10 px-7 py-4" style={{ background: C.bg, borderBottom: `1px solid ${C.border}` }}>
        <h2 style={{ color: C.text, fontSize: "1.25rem", fontWeight: 700 }}>Daily Sales Report</h2>
        <p className="text-sm" style={{ color: C.muted }}>Upload daily sales to refine AI stock predictions</p>
      </div>

      <div className="p-7 space-y-5">
        {/* Week Progress */}
        <div className="rounded-2xl p-5" style={{ background: C.card, border: `1px solid ${C.border}` }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <p style={{ color: C.text, fontWeight: 600, fontSize: "0.95rem" }}>Week Progress</p>
              <p className="text-sm" style={{ color: C.muted }}>Week of June 16 – 22, 2026</p>
            </div>
            <span className="px-3 py-1.5 rounded-xl text-sm" style={{ background: "rgba(22,246,134,0.1)", border: "1px solid rgba(22,246,134,0.25)", color: C.green, fontWeight: 700 }}>
              {uploadedCount}/7 days
            </span>
          </div>
          <div className="w-full rounded-full h-2 mb-5 overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
            <div className="h-2 rounded-full transition-all duration-500" style={{ width: `${(uploadedCount / 7) * 100}%`, background: `linear-gradient(90deg, ${C.cyan}, ${C.green})` }} />
          </div>
          <div className="grid grid-cols-7 gap-2">
            {days.map((day) => (
              <div key={day.label} className="flex flex-col items-center gap-1.5 p-2.5 rounded-xl border text-center" style={{
                background: day.status === "uploaded" ? "rgba(22,246,134,0.08)" : day.status === "pending" ? "rgba(238,230,56,0.08)" : "rgba(255,255,255,0.03)",
                borderColor: day.status === "uploaded" ? "rgba(22,246,134,0.25)" : day.status === "pending" ? "rgba(238,230,56,0.3)" : C.border,
              }}>
                <span className="text-xs" style={{ color: C.muted, fontWeight: 500 }}>{day.short}</span>
                {day.status === "uploaded" ? (
                  <CheckCircle className="w-4 h-4" style={{ color: C.green }} />
                ) : day.status === "pending" ? (
                  uploadingDay === day.label
                    ? <div className="w-4 h-4 rounded-full border-2 animate-spin" style={{ borderColor: `${C.yellow} transparent transparent transparent` }} />
                    : <div className="w-4 h-4 rounded-full" style={{ background: C.yellow }} />
                ) : (
                  <div className="w-4 h-4 rounded-full" style={{ background: "rgba(255,255,255,0.15)" }} />
                )}
                <span className="text-xs" style={{ color: day.status === "uploaded" ? C.green : day.status === "pending" ? C.yellow : C.dim, fontWeight: day.status === "pending" ? 600 : 400, fontSize: "0.6rem" }}>
                  {day.status === "uploaded" ? "Done" : day.status === "pending" ? "Today" : "—"}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Upload Zone */}
        <div className="rounded-2xl p-5" style={{ background: C.card, border: `1px solid ${C.border}` }}>
          <p style={{ color: C.text, fontWeight: 600, fontSize: "0.95rem", marginBottom: "1rem" }}>Upload Today's Sales File</p>
          <div
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => { e.preventDefault(); setIsDragging(false); simulateUpload(); }}
            onClick={simulateUpload}
            className="border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all"
            style={{ borderColor: isDragging ? C.cyan : "rgba(91,238,252,0.2)", background: isDragging ? "rgba(91,238,252,0.05)" : "transparent" }}
          >
            <UploadCloud className="w-8 h-8 mx-auto mb-2" style={{ color: C.cyan }} />
            <p className="text-sm" style={{ color: C.text, fontWeight: 500 }}>Drop your daily sales CSV or click to upload</p>
            <p className="text-xs mt-1" style={{ color: C.muted }}>CSV, XLSX — POS exports accepted</p>
          </div>
        </div>

        {/* AI Stock Suggestions Table */}
        <div className="rounded-2xl overflow-hidden" style={{ background: C.card, border: `1px solid ${C.border}` }}>
          <div className="px-5 py-4 flex items-center gap-3" style={{ borderBottom: `1px solid ${C.border}` }}>
            <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: "rgba(91,238,252,0.1)" }}>
              <TrendingUp className="w-4 h-4" style={{ color: C.cyan }} />
            </div>
            <div className="flex-1">
              <p style={{ color: C.text, fontWeight: 600, fontSize: "0.95rem" }}>AI Stock Suggestions for Next Week</p>
              <p className="text-xs" style={{ color: C.muted }}>Click any value to edit · Avg Usage & Order Qty are fully customizable</p>
            </div>
            <button onClick={exportCSV}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm transition-all hover:opacity-90"
              style={{ background: `linear-gradient(135deg, ${C.cyan}, ${C.green})`, color: C.bg, fontWeight: 700 }}>
              <Download className="w-4 h-4" />
              Export CSV
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ background: "rgba(255,255,255,0.02)", borderBottom: `1px solid ${C.border}` }}>
                  {["Ingredient", "Current Stock", "Avg Weekly Use ✏", "Order Qty ✏", "AI Reasoning"].map((h) => (
                    <th key={h} className="px-5 py-3 text-left text-xs uppercase tracking-wide" style={{ color: C.muted, fontWeight: 600 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {stockSuggestions.map((row) => {
                  const qty = quantities[row.ingredient] ?? row.aiSuggested;
                  const avg = avgUsage[row.ingredient] ?? row.aiAvgUsage;
                  const isEditingThisQty = editingQty === row.ingredient;
                  const isEditingThisAvg = editingAvg === row.ingredient;

                  return (
                    <tr key={row.ingredient} className="transition-colors" style={{ borderBottom: `1px solid rgba(255,255,255,0.03)` }}
                      onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.02)")}
                      onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-2">
                          <Package className="w-3.5 h-3.5 shrink-0" style={{ color: C.dim }} />
                          <span className="text-sm" style={{ color: C.text, fontWeight: 500 }}>{row.ingredient}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 text-sm" style={{ color: C.muted }}>
                        {row.currentStock} {row.unit}
                      </td>

                      {/* Editable Avg Usage */}
                      <td className="px-5 py-3.5">
                        {isEditingThisAvg ? (
                          <div className="flex items-center gap-1">
                            <input autoFocus type="number" value={tempVal} onChange={(e) => setTempVal(e.target.value)}
                              onKeyDown={(e) => { if (e.key === "Enter") commitEdit("avg", row.ingredient); if (e.key === "Escape") { setEditingAvg(null); setTempVal(""); } }}
                              className="w-16 px-2 py-1 rounded-lg text-sm text-center outline-none"
                              style={{ background: C.card2, border: `1px solid ${C.cyan}`, color: C.text, fontWeight: 600 }} />
                            <button onClick={() => commitEdit("avg", row.ingredient)} style={{ background: "none", border: "none" }}><Check className="w-3.5 h-3.5" style={{ color: C.green }} /></button>
                            <button onClick={() => { setEditingAvg(null); setTempVal(""); }} style={{ background: "none", border: "none" }}><X className="w-3.5 h-3.5" style={{ color: C.muted }} /></button>
                          </div>
                        ) : (
                          <button onClick={() => { setEditingAvg(row.ingredient); setTempVal(String(avg)); }}
                            className="flex items-center gap-1.5 group" style={{ background: "none", border: "none" }}>
                            <span className="text-sm" style={{ color: C.muted }}>{avg} {row.unit}</span>
                            <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: C.cyan }} />
                          </button>
                        )}
                      </td>

                      {/* Editable Order Qty */}
                      <td className="px-5 py-3.5">
                        {isEditingThisQty ? (
                          <div className="flex items-center gap-1">
                            <input autoFocus type="number" value={tempVal} onChange={(e) => setTempVal(e.target.value)}
                              onKeyDown={(e) => { if (e.key === "Enter") commitEdit("qty", row.ingredient); if (e.key === "Escape") { setEditingQty(null); setTempVal(""); } }}
                              className="w-16 px-2 py-1 rounded-lg text-sm text-center outline-none"
                              style={{ background: C.card2, border: `1px solid ${C.green}`, color: C.text, fontWeight: 700 }} />
                            <button onClick={() => commitEdit("qty", row.ingredient)} style={{ background: "none", border: "none" }}><Check className="w-3.5 h-3.5" style={{ color: C.green }} /></button>
                            <button onClick={() => { setEditingQty(null); setTempVal(""); }} style={{ background: "none", border: "none" }}><X className="w-3.5 h-3.5" style={{ color: C.muted }} /></button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <button onClick={() => adjustQty(row.ingredient, -1)}
                              className="w-6 h-6 rounded-lg flex items-center justify-center transition-colors"
                              style={{ background: "rgba(255,255,255,0.05)", border: `1px solid ${C.border}`, color: C.muted }}>
                              <Minus className="w-3 h-3" />
                            </button>
                            <button onClick={() => { setEditingQty(row.ingredient); setTempVal(String(qty)); }}
                              className="min-w-[3.5rem] text-center text-sm group flex items-center gap-1 justify-center"
                              style={{ background: "none", border: "none", color: qty === 0 ? C.dim : C.green, fontWeight: 700 }}>
                              {qty} {row.unit}
                              <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: C.cyan }} />
                            </button>
                            <button onClick={() => adjustQty(row.ingredient, 1)}
                              className="w-6 h-6 rounded-lg flex items-center justify-center transition-colors"
                              style={{ background: "rgba(255,255,255,0.05)", border: `1px solid ${C.border}`, color: C.muted }}>
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </td>

                      <td className="px-5 py-3.5">
                        <span className="text-xs" style={{ color: C.dim }}>{row.reason}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="px-5 py-4 flex items-center justify-between" style={{ borderTop: `1px solid ${C.border}` }}>
            <p className="text-xs" style={{ color: C.dim }}>
              {uploadedCount}/7 days of sales data · Click values to edit · Changes saved automatically
            </p>
            <button onClick={exportCSV}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm transition-all hover:opacity-90"
              style={{ background: "rgba(91,238,252,0.1)", border: `1px solid rgba(91,238,252,0.25)`, color: C.cyan, fontWeight: 600 }}>
              <Download className="w-3.5 h-3.5" />
              Export Order List
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
