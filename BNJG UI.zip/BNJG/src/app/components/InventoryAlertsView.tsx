import { useState } from "react";
import { X, Tag, TrendingDown, Package, Zap, CheckCircle, ChevronDown, ChevronUp, Minus } from "lucide-react";

const C = {
  bg: "#151A1F", card: "#1A2027", card2: "#1F2831", border: "rgba(255,255,255,0.07)",
  cyan: "#5BEEFC", green: "#16F686", yellow: "#EEE638",
  text: "#FFFFFF", muted: "rgba(255,255,255,0.5)", dim: "rgba(255,255,255,0.22)",
};

type AlertLevel = "critical" | "high" | "medium";

interface OverstockAlert {
  id: string;
  item: string;
  currentStock: string;
  threshold: string;
  excessQty: string;
  level: AlertLevel;
  emoji: string;
  daysToSpoil: number;
  purchasedDate: string;
  storageNote: string;
  usedInMenus: { dish: string; qty: string }[];
  discount: {
    dish: string;
    percent: number;
    rationale: string;
    estimatedSales: string;
    stockMoved: string;
  };
}

const alerts: OverstockAlert[] = [
  {
    id: "basil",
    item: "Fresh Basil",
    currentStock: "4.2 kg",
    threshold: "1.5 kg",
    excessQty: "2.7 kg",
    level: "critical",
    emoji: "🌿",
    daysToSpoil: 1,
    purchasedDate: "Jun 18",
    storageNote: "Refrigerated · wilts rapidly after day 3",
    usedInMenus: [
      { dish: "Margherita Pizza", qty: "12 g / serve" },
      { dish: "Caprese Salad", qty: "8 g / serve" },
      { dish: "Pesto Pasta", qty: "20 g / serve" },
    ],
    discount: {
      dish: "Caprese Salad",
      percent: 20,
      rationale: "Fresh basil has a 2–3 day shelf life from purchase. A 20% happy-hour discount on Caprese Salad (2–5pm) can move approximately 2.1 kg of basil before spoilage.",
      estimatedSales: "+15 units / day",
      stockMoved: "~2.1 kg in 2 days",
    },
  },
  {
    id: "tomatoes",
    item: "San Marzano Tomatoes",
    currentStock: "18 kg",
    threshold: "9 kg",
    excessQty: "9 kg",
    level: "critical",
    emoji: "🍅",
    daysToSpoil: 2,
    purchasedDate: "Jun 17",
    storageNote: "Room temperature · soft spots forming, use immediately",
    usedInMenus: [
      { dish: "Margherita Pizza", qty: "320 g / serve" },
      { dish: "Caprese Salad", qty: "200 g / serve" },
      { dish: "Pasta Arrabbiata", qty: "180 g / serve" },
    ],
    discount: {
      dish: "Margherita Pizza",
      percent: 15,
      rationale: "Margherita Pizza uses 320 g of tomato per serving. A 15% discount is projected to drive 8–12 additional orders per day, consuming approximately 3.5 kg of tomato stock daily.",
      estimatedSales: "+10 units / day",
      stockMoved: "~3.5 kg / day",
    },
  },
  {
    id: "mozzarella",
    item: "Mozzarella di Bufala",
    currentStock: "8 kg",
    threshold: "5 kg",
    excessQty: "3 kg",
    level: "high",
    emoji: "🧀",
    daysToSpoil: 4,
    purchasedDate: "Jun 16",
    storageNote: "Refrigerated in brine · 5-day window from purchase date",
    usedInMenus: [
      { dish: "Margherita Pizza", qty: "150 g / serve" },
      { dish: "Caprese Salad", qty: "120 g / serve" },
    ],
    discount: {
      dish: "Margherita Pizza",
      percent: 10,
      rationale: "A 'Chef's Pick' bundle featuring Margherita and Caprese at 10% off this weekend is sufficient to deplete the excess before the 5-day brine window closes.",
      estimatedSales: "+8 units / day",
      stockMoved: "~1.4 kg / day",
    },
  },
  {
    id: "pizza-dough",
    item: "Pizza Dough Balls",
    currentStock: "62 units",
    threshold: "40 units",
    excessQty: "22 units",
    level: "medium",
    emoji: "🍕",
    daysToSpoil: 3,
    purchasedDate: "Jun 18",
    storageNote: "Refrigerated proofed dough · degrades after 72 hrs",
    usedInMenus: [
      { dish: "Margherita Pizza", qty: "1 ball / serve" },
      { dish: "Quattro Stagioni", qty: "1 ball / serve" },
      { dish: "Calzone", qty: "2 balls / serve" },
    ],
    discount: {
      dish: "Calzone",
      percent: 12,
      rationale: "Calzone consumes 2 dough balls per serving. A Weekend Special at 12% off is projected to drive sufficient calzone orders to clear the 22-unit excess before Monday.",
      estimatedSales: "+6 units / day",
      stockMoved: "~12 dough balls / day",
    },
  },
];

const levelLabel: Record<AlertLevel, string> = {
  critical: "Critical",
  high: "High",
  medium: "Medium",
};

const spoilLabel = (days: number) => {
  if (days <= 0) return "Expires today";
  if (days === 1) return "Expires tomorrow";
  return `Expires in ${days} days`;
};

export function InventoryAlertsView() {
  const [modalAlert, setModalAlert] = useState<OverstockAlert | null>(null);
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());
  const [resolved, setResolved] = useState<Set<string>>(new Set());
  const [expanded, setExpanded] = useState<string | null>(null);

  const visible = alerts
    .filter((a) => !dismissed.has(a.id))
    .sort((a, b) => a.daysToSpoil - b.daysToSpoil);

  const criticalCount = visible.filter((a) => a.level === "critical").length;

  return (
    <div className="flex-1 overflow-y-auto" style={{ background: C.bg }}>
      {/* Header */}
      <div className="sticky top-0 z-10 px-7 py-4 flex items-center justify-between" style={{ background: C.bg, borderBottom: `1px solid ${C.border}` }}>
        <div>
          <h2 style={{ color: C.text, fontSize: "1.25rem", fontWeight: 700 }}>Inventory Alerts</h2>
          <p className="text-sm" style={{ color: C.muted }}>Cross-referenced against cookbook SOP · Sorted by spoil urgency</p>
        </div>
        <div className="flex items-center gap-3 text-xs" style={{ color: C.dim }}>
          {criticalCount > 0 && (
            <span style={{ color: C.muted }}>{criticalCount} critical</span>
          )}
          <span style={{ color: C.dim }}>{visible.length} active alerts</span>
        </div>
      </div>

      <div className="p-7">
        {visible.length === 0 ? (
          <div className="text-center py-16">
            <CheckCircle className="w-10 h-10 mx-auto mb-3" style={{ color: C.green }} />
            <p style={{ color: C.text, fontWeight: 600 }}>No active alerts</p>
            <p className="text-sm mt-1" style={{ color: C.muted }}>All inventory levels are within acceptable thresholds.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {visible.map((alert) => {
              const isResolved = resolved.has(alert.id);
              const isExpanded = expanded === alert.id;
              const urgentColor = alert.daysToSpoil <= 1 ? "#FF6B6B" : alert.daysToSpoil <= 2 ? C.yellow : C.muted;

              return (
                <div key={alert.id} className="rounded-xl overflow-hidden" style={{
                  background: C.card,
                  border: `1px solid ${C.border}`,
                  borderLeft: `3px solid ${alert.daysToSpoil <= 1 ? "#FF6B6B" : alert.daysToSpoil <= 2 ? C.yellow : alert.daysToSpoil <= 4 ? "rgba(255,255,255,0.2)" : C.border}`,
                }}>
                  {/* Main row */}
                  <div className="flex items-center gap-4 px-5 py-4">
                    <span className="text-xl shrink-0">{alert.emoji}</span>

                    {/* Item name + level */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm" style={{ color: C.text, fontWeight: 600 }}>{alert.item}</span>
                        <span className="text-xs" style={{ color: C.dim }}>·</span>
                        <span className="text-xs" style={{ color: C.muted }}>{levelLabel[alert.level]} overstock</span>
                        <span className="text-xs" style={{ color: C.dim }}>·</span>
                        <span className="text-xs" style={{ color: urgentColor, fontWeight: 600 }}>{spoilLabel(alert.daysToSpoil)}</span>
                      </div>
                      <p className="text-xs mt-0.5" style={{ color: C.dim }}>{alert.storageNote}</p>
                    </div>

                    {/* Stock numbers */}
                    <div className="flex items-center gap-6 shrink-0 text-center">
                      <div>
                        <p className="text-xs uppercase tracking-wide mb-0.5" style={{ color: C.dim, fontSize: "0.6rem" }}>Stock</p>
                        <p className="text-sm" style={{ color: C.text, fontWeight: 700 }}>{alert.currentStock}</p>
                      </div>
                      <div>
                        <p className="text-xs uppercase tracking-wide mb-0.5" style={{ color: C.dim, fontSize: "0.6rem" }}>Threshold</p>
                        <p className="text-sm" style={{ color: C.muted }}>{alert.threshold}</p>
                      </div>
                      <div>
                        <p className="text-xs uppercase tracking-wide mb-0.5" style={{ color: C.dim, fontSize: "0.6rem" }}>Excess</p>
                        <p className="text-sm" style={{ color: urgentColor, fontWeight: 700 }}>{alert.excessQty}</p>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => setExpanded(isExpanded ? null : alert.id)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs transition-colors"
                        style={{ background: "rgba(255,255,255,0.05)", border: `1px solid ${C.border}`, color: C.muted }}>
                        Menu usage
                        {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      </button>

                      {isResolved ? (
                        <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs"
                          style={{ background: "rgba(22,246,134,0.08)", border: "1px solid rgba(22,246,134,0.2)", color: C.green, fontWeight: 600 }}>
                          <CheckCircle className="w-3.5 h-3.5" /> Activated
                        </span>
                      ) : (
                        <button onClick={() => setModalAlert(alert)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-colors hover:opacity-90"
                          style={{ background: "rgba(91,238,252,0.1)", border: `1px solid rgba(91,238,252,0.25)`, color: C.cyan, fontWeight: 600 }}>
                          <Zap className="w-3.5 h-3.5" /> Discount
                        </button>
                      )}

                      <button onClick={() => setDismissed((prev) => new Set([...prev, alert.id]))}
                        className="w-7 h-7 flex items-center justify-center rounded-lg transition-colors"
                        style={{ background: "none", border: `1px solid ${C.border}`, color: C.dim }}>
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Expanded: menu usage */}
                  {isExpanded && (
                    <div className="px-5 pb-4" style={{ borderTop: `1px solid rgba(255,255,255,0.04)` }}>
                      <p className="text-xs uppercase tracking-wide mt-3 mb-2" style={{ color: C.dim, fontWeight: 600 }}>Used in</p>
                      <table className="w-full">
                        <thead>
                          <tr>
                            {["Menu Item", "Quantity per Serving", "Daily Burn (est.)"].map((h) => (
                              <th key={h} className="text-left text-xs pb-1.5" style={{ color: C.dim, fontWeight: 600, fontSize: "0.7rem" }}>{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {alert.usedInMenus.map((m) => (
                            <tr key={m.dish}>
                              <td className="py-1.5 text-sm pr-6" style={{ color: C.text }}>{m.dish}</td>
                              <td className="py-1.5 text-sm pr-6" style={{ color: C.muted }}>{m.qty}</td>
                              <td className="py-1.5 text-xs" style={{ color: C.dim }}>Based on avg weekly sales</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Discount Modal */}
      {modalAlert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6"
          style={{ background: "rgba(0,0,0,0.65)" }}
          onClick={(e) => { if (e.target === e.currentTarget) setModalAlert(null); }}>
          <div className="rounded-2xl w-full max-w-md overflow-hidden" style={{ background: C.card, border: `1px solid ${C.border}` }}>
            {/* Modal header */}
            <div className="px-6 py-5 flex items-center justify-between" style={{ borderBottom: `1px solid ${C.border}` }}>
              <div>
                <p className="text-xs uppercase tracking-wide mb-1" style={{ color: C.dim, fontWeight: 600 }}>Discount Initiative</p>
                <p style={{ color: C.text, fontWeight: 700 }}>{modalAlert.item}</p>
              </div>
              <button onClick={() => setModalAlert(null)}
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ background: "rgba(255,255,255,0.05)", border: `1px solid ${C.border}`, color: C.muted }}>
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {/* Recommendation */}
              <div>
                <p className="text-xs uppercase tracking-wide mb-2" style={{ color: C.dim, fontWeight: 600 }}>Recommended Action</p>
                <div className="flex items-start gap-3 p-4 rounded-xl" style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${C.border}` }}>
                  <Tag className="w-4 h-4 mt-0.5 shrink-0" style={{ color: C.cyan }} />
                  <div>
                    <p className="text-sm mb-1" style={{ color: C.text, fontWeight: 600 }}>
                      {modalAlert.discount.percent}% discount on {modalAlert.discount.dish}
                    </p>
                    <p className="text-sm leading-relaxed" style={{ color: C.muted }}>{modalAlert.discount.rationale}</p>
                  </div>
                </div>
              </div>

              {/* Projections */}
              <div>
                <p className="text-xs uppercase tracking-wide mb-2" style={{ color: C.dim, fontWeight: 600 }}>Projected Impact</p>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { icon: TrendingDown, label: "Additional sales", value: modalAlert.discount.estimatedSales },
                    { icon: Package, label: "Stock moved", value: modalAlert.discount.stockMoved },
                  ].map((s) => {
                    const Icon = s.icon;
                    return (
                      <div key={s.label} className="flex items-center gap-3 p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.03)", border: `1px solid ${C.border}` }}>
                        <Icon className="w-4 h-4 shrink-0" style={{ color: C.muted }} />
                        <div>
                          <p className="text-sm" style={{ color: C.text, fontWeight: 700 }}>{s.value}</p>
                          <p className="text-xs" style={{ color: C.dim }}>{s.label}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-1">
                <button onClick={() => setModalAlert(null)}
                  className="flex-1 py-3 rounded-xl text-sm transition-colors"
                  style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${C.border}`, color: C.muted, fontWeight: 500 }}>
                  Dismiss
                </button>
                <button
                  onClick={() => { setResolved((prev) => new Set([...prev, modalAlert.id])); setModalAlert(null); }}
                  className="flex-1 py-3 rounded-xl text-sm transition-all hover:opacity-90"
                  style={{ background: `linear-gradient(135deg, ${C.cyan}, ${C.green})`, color: C.bg, fontWeight: 700 }}>
                  Activate Initiative
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
