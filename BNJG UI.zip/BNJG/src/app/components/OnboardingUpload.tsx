import { useState, useRef } from "react";
import { Upload, FileText, CheckCircle, Leaf, ChefHat, Loader } from "lucide-react";

const C = {
  bg: "#151A1F", card: "#1A2027", border: "rgba(255,255,255,0.07)",
  cyan: "#5BEEFC", green: "#16F686", yellow: "#EEE638",
  text: "#FFFFFF", muted: "rgba(255,255,255,0.5)", input: "#1F2831",
};

interface OnboardingUploadProps {
  onComplete: () => void;
}

type UploadState = "idle" | "dragging" | "uploading" | "analyzing" | "done";

const extractedIngredients = [
  { dish: "Margherita Pizza", ingredients: ["San Marzano Tomatoes", "Mozzarella di Bufala", "Fresh Basil", "Pizza Dough", "Olive Oil"] },
  { dish: "Pasta Carbonara", ingredients: ["Spaghetti", "Pancetta", "Eggs", "Pecorino Romano", "Black Pepper"] },
  { dish: "Grilled Ribeye Steak", ingredients: ["Ribeye Steak", "Rosemary", "Garlic", "Butter", "Sea Salt"] },
  { dish: "Caprese Salad", ingredients: ["San Marzano Tomatoes", "Mozzarella di Bufala", "Fresh Basil", "Balsamic Vinegar", "Olive Oil"] },
  { dish: "Tiramisu", ingredients: ["Mascarpone", "Espresso", "Ladyfingers", "Eggs", "Cocoa Powder"] },
];

export function OnboardingUpload({ onComplete }: OnboardingUploadProps) {
  const [state, setState] = useState<UploadState>("idle");
  const [fileName, setFileName] = useState("");
  const [progress, setProgress] = useState(0);
  const fileRef = useRef<HTMLInputElement>(null);

  const simulateUpload = (name: string) => {
    setFileName(name);
    setState("uploading");
    let p = 0;
    const interval = setInterval(() => {
      p += Math.random() * 20 + 5;
      if (p >= 100) {
        clearInterval(interval);
        setProgress(100);
        setState("analyzing");
        setTimeout(() => setState("done"), 2000);
      } else {
        setProgress(p);
      }
    }, 200);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6" style={{ background: C.bg }}>
      <div className="w-full max-w-2xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full mb-4" style={{ background: "rgba(91,238,252,0.1)", border: `1px solid rgba(91,238,252,0.25)` }}>
            <Leaf className="w-3.5 h-3.5" style={{ color: C.cyan }} />
            <span className="text-xs" style={{ color: C.cyan, fontWeight: 600 }}>Step 2 of 2 — Onboarding</span>
          </div>
          <h1 style={{ color: C.text, fontSize: "1.75rem", fontWeight: 700 }}>Upload Your Cookbook (SOP)</h1>
          <p style={{ color: C.muted, fontSize: "0.875rem", marginTop: "0.5rem" }}>
            Our AI extracts all ingredients per menu item to track your stock usage.
          </p>
        </div>

        <div className="rounded-2xl overflow-hidden" style={{ background: C.card, border: `1px solid ${C.border}` }}>
          {state === "idle" || state === "dragging" ? (
            <div className="p-8">
              <div
                onDragOver={(e) => { e.preventDefault(); setState("dragging"); }}
                onDragLeave={() => setState("idle")}
                onDrop={(e) => { e.preventDefault(); setState("idle"); const f = e.dataTransfer.files[0]; if (f) simulateUpload(f.name); }}
                onClick={() => fileRef.current?.click()}
                className="border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all"
                style={{
                  borderColor: state === "dragging" ? C.cyan : "rgba(91,238,252,0.25)",
                  background: state === "dragging" ? "rgba(91,238,252,0.05)" : "transparent",
                }}
              >
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4" style={{ background: "rgba(91,238,252,0.1)" }}>
                  <Upload className="w-7 h-7" style={{ color: C.cyan }} />
                </div>
                <p style={{ color: C.text, fontWeight: 600 }}>{state === "dragging" ? "Drop your file here" : "Drag & drop your cookbook"}</p>
                <p style={{ color: C.muted, fontSize: "0.875rem" }}>PDF, DOCX, or XLSX accepted</p>
                <input ref={fileRef} type="file" accept=".pdf,.docx,.xlsx" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) simulateUpload(f.name); }} />
              </div>
            </div>
          ) : state === "uploading" ? (
            <div className="p-8 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4" style={{ background: "rgba(91,238,252,0.1)" }}>
                <FileText className="w-7 h-7" style={{ color: C.cyan }} />
              </div>
              <p style={{ color: C.text, fontWeight: 600 }}>{fileName}</p>
              <p style={{ color: C.muted, fontSize: "0.875rem", marginBottom: "1.5rem" }}>Uploading file…</p>
              <div className="w-full rounded-full h-2 mb-2 overflow-hidden" style={{ background: "rgba(255,255,255,0.08)" }}>
                <div className="h-2 rounded-full transition-all duration-200" style={{ width: `${progress}%`, background: `linear-gradient(90deg, ${C.cyan}, ${C.green})` }} />
              </div>
              <p style={{ color: C.muted, fontSize: "0.75rem" }}>{Math.round(progress)}%</p>
            </div>
          ) : state === "analyzing" ? (
            <div className="p-8 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4" style={{ background: "rgba(22,246,134,0.1)" }}>
                <Loader className="w-7 h-7 animate-spin" style={{ color: C.green }} />
              </div>
              <p style={{ color: C.text, fontWeight: 600 }}>Analyzing Cookbook…</p>
              <p style={{ color: C.muted, fontSize: "0.875rem" }}>AI is extracting ingredients from your menu items</p>
            </div>
          ) : (
            <div className="p-8">
              <div className="text-center mb-6">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4" style={{ background: "rgba(22,246,134,0.1)" }}>
                  <CheckCircle className="w-7 h-7" style={{ color: C.green }} />
                </div>
                <p style={{ color: C.text, fontWeight: 600 }}>Cookbook Analyzed Successfully!</p>
                <p style={{ color: C.muted, fontSize: "0.875rem" }}>
                  Found <span style={{ color: C.cyan, fontWeight: 700 }}>5 menu items</span> with <span style={{ color: C.green, fontWeight: 700 }}>23 unique ingredients</span>
                </p>
              </div>
              <div className="space-y-2 mb-6">
                {extractedIngredients.map((item) => (
                  <div key={item.dish} className="flex items-start gap-3 p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${C.border}` }}>
                    <ChefHat className="w-4 h-4 mt-0.5 shrink-0" style={{ color: C.cyan }} />
                    <div className="min-w-0">
                      <p className="text-sm" style={{ color: C.text, fontWeight: 600 }}>{item.dish}</p>
                      <p className="text-xs mt-0.5" style={{ color: C.muted }}>{item.ingredients.join(" · ")}</p>
                    </div>
                  </div>
                ))}
              </div>
              <button onClick={onComplete}
                className="w-full py-3.5 rounded-xl text-sm transition-all hover:opacity-90"
                style={{ background: `linear-gradient(135deg, ${C.cyan}, ${C.green})`, color: C.bg, fontWeight: 700 }}
              >
                Go to Dashboard →
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
