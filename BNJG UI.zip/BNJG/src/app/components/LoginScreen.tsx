import { useState } from "react";
import { Leaf, Mail, Lock, User, Eye, EyeOff } from "lucide-react";

const C = {
  bg: "#151A1F",
  card: "#1A2027",
  border: "rgba(255,255,255,0.07)",
  cyan: "#5BEEFC",
  green: "#16F686",
  yellow: "#EEE638",
  text: "#FFFFFF",
  muted: "rgba(255,255,255,0.5)",
  input: "#1F2831",
};

interface LoginScreenProps {
  onLogin: () => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [tab, setTab] = useState<"login" | "signup">("login");
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");

  return (
    <div className="min-h-screen flex items-center justify-center p-6" style={{ background: C.bg }}>
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div
            className="inline-flex items-center justify-center w-14 h-14 rounded-2xl mb-4"
            style={{ background: `linear-gradient(135deg, ${C.cyan}, ${C.green})` }}
          >
            <Leaf className="w-7 h-7" style={{ color: C.bg }} />
          </div>
          <h1 style={{ color: C.text, fontSize: "1.75rem", fontWeight: 700 }}>BNJGFoodSolutions</h1>
          <p style={{ color: C.muted, fontSize: "0.875rem", marginTop: "0.25rem" }}>
            AI-powered food waste reduction for restaurants
          </p>
        </div>

        <div className="rounded-2xl overflow-hidden" style={{ background: C.card, border: `1px solid ${C.border}` }}>
          <div className="flex" style={{ borderBottom: `1px solid ${C.border}` }}>
            {(["login", "signup"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className="flex-1 py-4 text-sm transition-colors"
                style={{
                  color: tab === t ? C.cyan : C.muted,
                  borderBottom: `2px solid ${tab === t ? C.cyan : "transparent"}`,
                  fontWeight: tab === t ? 600 : 400,
                  background: "none",
                }}
              >
                {t === "login" ? "Sign In" : "Create Account"}
              </button>
            ))}
          </div>

          <div className="p-8">
            <form onSubmit={(e) => { e.preventDefault(); onLogin(); }} className="space-y-5">
              {tab === "signup" && (
                <div>
                  <label className="block text-sm mb-1.5" style={{ color: C.muted, fontWeight: 500 }}>Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: C.muted }} />
                    <input
                      type="text" placeholder="Marco Rossi" value={name} onChange={(e) => setName(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 rounded-xl text-sm outline-none transition-all"
                      style={{ background: C.input, border: `1px solid ${C.border}`, color: C.text, fontWeight: 400 }}
                      onFocus={(e) => e.target.style.borderColor = C.cyan}
                      onBlur={(e) => e.target.style.borderColor = C.border}
                    />
                  </div>
                </div>
              )}
              <div>
                <label className="block text-sm mb-1.5" style={{ color: C.muted, fontWeight: 500 }}>Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: C.muted }} />
                  <input
                    type="email" placeholder="manager@trattoria.com" value={email} onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 rounded-xl text-sm outline-none transition-all"
                    style={{ background: C.input, border: `1px solid ${C.border}`, color: C.text, fontWeight: 400 }}
                    onFocus={(e) => e.target.style.borderColor = C.cyan}
                    onBlur={(e) => e.target.style.borderColor = C.border}
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm mb-1.5" style={{ color: C.muted, fontWeight: 500 }}>Password</label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: C.muted }} />
                  <input
                    type={showPassword ? "text" : "password"} placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-11 py-3 rounded-xl text-sm outline-none transition-all"
                    style={{ background: C.input, border: `1px solid ${C.border}`, color: C.text, fontWeight: 400 }}
                    onFocus={(e) => e.target.style.borderColor = C.cyan}
                    onBlur={(e) => e.target.style.borderColor = C.border}
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 transition-colors"
                    style={{ background: "none", border: "none", color: C.muted }}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <button
                type="submit"
                className="w-full py-3.5 rounded-xl text-sm transition-all hover:opacity-90 active:scale-[0.98]"
                style={{ background: `linear-gradient(135deg, ${C.cyan}, ${C.green})`, color: C.bg, fontWeight: 700 }}
              >
                {tab === "login" ? "Sign In to Dashboard" : "Create Account"}
              </button>
            </form>
            <p className="text-center text-xs mt-6" style={{ color: "rgba(255,255,255,0.25)" }}>
              Demo: use any credentials to sign in
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
