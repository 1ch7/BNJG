import { TrendingDown, TrendingUp, AlertTriangle, Package, ArrowUpRight, Leaf, Clock, ShieldCheck, Recycle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import type { View } from "./types";

const C = {
  bg: "#151A1F", card: "#1A2027", card2: "#1F2831", border: "rgba(255,255,255,0.07)",
  cyan: "#5BEEFC", green: "#16F686", yellow: "#EEE638",
  text: "#FFFFFF", muted: "rgba(255,255,255,0.5)", dim: "rgba(255,255,255,0.25)",
};

interface DashboardOverviewProps {
  onNavigate: (view: View) => void;
}

const weeklyRevenueData = [
  { day: "Mon", thisWeek: 2840, lastWeek: 2310 },
  { day: "Tue", thisWeek: 2650, lastWeek: 2480 },
  { day: "Wed", thisWeek: 1920, lastWeek: 2700 },
  { day: "Thu", thisWeek: 3140, lastWeek: 2890 },
  { day: "Fri", thisWeek: 4280, lastWeek: 3760 },
  { day: "Sat", thisWeek: 5610, lastWeek: 4920 },
  { day: "Sun", thisWeek: 0, lastWeek: 5130 },
];

const burnRateData = [
  { ingredient: "Fresh Basil",          ordered: 9,  used: 5.0, unit: "bunches" },
  { ingredient: "Mozzarella di Bufala", ordered: 10, used: 7.0, unit: "kg"      },
  { ingredient: "San Marzano Tomatoes", ordered: 12, used: 9.0, unit: "kg"      },
  { ingredient: "Olive Oil",            ordered: 8,  used: 6.0, unit: "L"       },
  { ingredient: "Mascarpone",           ordered: 3,  used: 2.4, unit: "kg"      },
  { ingredient: "Pecorino Romano",      ordered: 3,  used: 2.5, unit: "kg"      },
  { ingredient: "Pizza Dough Balls",    ordered: 55, used: 48,  unit: "units"   },
  { ingredient: "Pancetta",             ordered: 5,  used: 4.5, unit: "kg"      },
  { ingredient: "Garlic",               ordered: 3,  used: 2.8, unit: "kg"      },
  { ingredient: "Ribeye Steak",         ordered: 8,  used: 8.0, unit: "kg"      },
].map((r) => ({ ...r, pct: Math.round((r.used / r.ordered) * 100) }))
  .sort((a, b) => a.pct - b.pct);

const kpiCards = [
  { label: "Stock Efficiency", value: "78%", sub: "+6% vs last month", trend: "up", icon: ShieldCheck, color: C.cyan, glow: "rgba(91,238,252,0.15)" },
  { label: "Recovered Value", value: "€840", sub: "from discount initiatives", trend: "up", icon: Recycle, color: C.green, glow: "rgba(22,246,134,0.15)" },
  { label: "Waste Cost Avoided", value: "€2,340", sub: "AI-driven savings this month", trend: "up", icon: TrendingDown, color: C.green, glow: "rgba(22,246,134,0.15)" },
  { label: "Active Alerts", value: "4", sub: "2 critical, 2 high", trend: "down", icon: AlertTriangle, color: C.yellow, glow: "rgba(238,230,56,0.15)" },
  { label: "Items at Risk", value: "3", sub: "expire within 48 hrs", trend: "down", icon: Clock, color: "#FF6B6B", glow: "rgba(255,107,107,0.15)" },
  { label: "Items Tracked", value: "142", sub: "+8 since last week", trend: "up", icon: Package, color: C.cyan, glow: "rgba(91,238,252,0.15)" },
];

const recentAlerts = [
  { item: "San Marzano Tomatoes", level: "critical", excess: "9 kg", expires: "2 days" },
  { item: "Fresh Basil", level: "critical", excess: "2.7 kg", expires: "1 day" },
  { item: "Mozzarella di Bufala", level: "high", excess: "3 kg", expires: "4 days" },
  { item: "Pizza Dough Balls", level: "high", excess: "22 units", expires: "3 days" },
];

const levelColors: Record<string, string> = {
  critical: "#FF6B6B",
  high: C.yellow,
  medium: C.cyan,
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="rounded-xl p-3" style={{ background: "#252D36", border: `1px solid ${C.border}` }}>
        <p className="text-xs mb-1" style={{ color: C.muted, fontWeight: 600 }}>{label}</p>
        {payload.map((p: any) => (
          <p key={p.dataKey} className="text-xs" style={{ color: p.color, fontWeight: 600 }}>
            {p.name}: €{p.value.toLocaleString()}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export function DashboardOverview({ onNavigate }: DashboardOverviewProps) {
  return (
    <div className="flex-1 overflow-y-auto" style={{ background: C.bg }}>
      {/* Header */}
      <div className="sticky top-0 z-10 px-7 py-4 flex items-center justify-between" style={{ background: C.bg, borderBottom: `1px solid ${C.border}` }}>
        <div>
          <p className="text-sm" style={{ color: C.muted }}>Good morning,</p>
          <h2 style={{ color: C.text, fontSize: "1.25rem", fontWeight: 700 }}>Welcome back, Marco 👋</h2>
        </div>
        <span className="px-3 py-1.5 rounded-lg text-xs" style={{ background: "rgba(91,238,252,0.1)", border: `1px solid rgba(91,238,252,0.25)`, color: C.cyan, fontWeight: 600 }}>
          Friday, 20 Jun 2026
        </span>
      </div>

      <div className="p-7 space-y-5">
        {/* KPI Grid */}
        <div className="grid grid-cols-3 gap-4">
          {kpiCards.map((card) => {
            const Icon = card.icon;
            return (
              <div key={card.label} className="rounded-2xl p-5" style={{ background: C.card, border: `1px solid ${C.border}` }}>
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: card.glow }}>
                    <Icon className="w-5 h-5" style={{ color: card.color }} />
                  </div>
                  <span className="flex items-center gap-0.5 text-xs" style={{ color: card.trend === "up" ? C.green : "#FF6B6B", fontWeight: 600 }}>
                    {card.trend === "up" ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                  </span>
                </div>
                <p style={{ color: C.text, fontSize: "1.6rem", fontWeight: 700, lineHeight: 1 }}>{card.value}</p>
                <p className="text-xs mt-0.5" style={{ color: card.color, fontWeight: 600 }}>{card.label}</p>
                <p className="text-xs mt-1" style={{ color: C.dim }}>{card.sub}</p>
              </div>
            );
          })}
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-2 gap-4">
          {/* Weekly Revenue Chart */}
          <div className="rounded-2xl p-5" style={{ background: C.card, border: `1px solid ${C.border}` }}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p style={{ color: C.text, fontWeight: 600, fontSize: "0.9rem" }}>Weekly Revenue</p>
                <p className="text-xs" style={{ color: C.muted }}>This week vs last week</p>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span className="flex items-center gap-1" style={{ color: C.cyan }}><span className="w-2 h-2 rounded-full inline-block" style={{ background: C.cyan }} />This week</span>
                <span className="flex items-center gap-1" style={{ color: C.muted }}><span className="w-2 h-2 rounded-full inline-block" style={{ background: "rgba(255,255,255,0.25)" }} />Last week</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={weeklyRevenueData} margin={{ top: 0, right: 0, left: -25, bottom: 0 }} barGap={3}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: C.muted }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 9, fill: C.muted }} tickLine={false} axisLine={false} tickFormatter={(v) => `€${(v/1000).toFixed(1)}k`} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
                <Bar dataKey="thisWeek" name="This Week" fill={C.cyan} radius={[4, 4, 0, 0]} fillOpacity={0.9} />
                <Bar dataKey="lastWeek" name="Last Week" fill="rgba(255,255,255,0.15)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Stock Burn Rate vs Ordered */}
          <div className="rounded-2xl p-5 flex flex-col" style={{ background: C.card, border: `1px solid ${C.border}` }}>
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div>
                <p style={{ color: C.text, fontWeight: 600, fontSize: "0.9rem" }}>Stock Burn Rate vs. Ordered</p>
                <p className="text-xs" style={{ color: C.muted }}>This week · sorted by lowest utilisation</p>
              </div>
              <div className="flex items-center gap-3 text-xs shrink-0">
                <span className="flex items-center gap-1.5" style={{ color: C.green }}>
                  <span className="w-2 h-2 rounded-sm inline-block" style={{ background: C.green }} />≥85%
                </span>
                <span className="flex items-center gap-1.5" style={{ color: C.yellow }}>
                  <span className="w-2 h-2 rounded-sm inline-block" style={{ background: C.yellow }} />65–84%
                </span>
                <span className="flex items-center gap-1.5" style={{ color: "#FF6B6B" }}>
                  <span className="w-2 h-2 rounded-sm inline-block" style={{ background: "#FF6B6B" }} />&lt;65%
                </span>
              </div>
            </div>

            {/* Rows */}
            <div className="flex flex-col gap-2.5">
              {burnRateData.map((row) => {
                const barColor =
                  row.pct >= 85 ? C.green :
                  row.pct >= 65 ? C.yellow :
                  "#FF6B6B";

                return (
                  <div key={row.ingredient} className="flex items-center gap-3">
                    {/* Ingredient name */}
                    <p className="text-xs shrink-0 text-right" style={{ color: C.muted, width: "148px", fontWeight: 500 }}>
                      {row.ingredient}
                    </p>

                    {/* Bar track */}
                    <div className="flex-1 relative h-4 rounded-sm overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
                      {/* Used fill */}
                      <div
                        className="absolute inset-y-0 left-0 rounded-sm transition-all"
                        style={{ width: `${row.pct}%`, background: barColor, opacity: 0.85 }}
                      />
                      {/* Ordered marker line at 100% */}
                      <div className="absolute inset-y-0 right-0 w-px" style={{ background: "rgba(255,255,255,0.15)" }} />
                    </div>

                    {/* Stats */}
                    <div className="flex items-center gap-2 shrink-0" style={{ width: "130px" }}>
                      <span className="text-xs" style={{ color: barColor, fontWeight: 700, width: "32px", textAlign: "right" }}>
                        {row.pct}%
                      </span>
                      <span className="text-xs" style={{ color: C.dim }}>
                        {row.used}/{row.ordered} {row.unit}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Footer summary */}
            <div className="mt-4 pt-3.5 flex items-center justify-between" style={{ borderTop: `1px solid ${C.border}` }}>
              {[
                { label: "Avg utilisation", value: `${Math.round(burnRateData.reduce((s, r) => s + r.pct, 0) / burnRateData.length)}%`, color: C.cyan },
                { label: "Under 65%", value: `${burnRateData.filter((r) => r.pct < 65).length} items`, color: "#FF6B6B" },
                { label: "At full use", value: `${burnRateData.filter((r) => r.pct >= 95).length} items`, color: C.green },
              ].map((s) => (
                <div key={s.label} className="text-center">
                  <p className="text-sm" style={{ color: s.color, fontWeight: 700 }}>{s.value}</p>
                  <p className="text-xs" style={{ color: C.dim }}>{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-3 gap-4">
          {/* Recent Alerts */}
          <div className="col-span-2 rounded-2xl overflow-hidden" style={{ background: C.card, border: `1px solid ${C.border}` }}>
            <div className="px-5 py-4 flex items-center justify-between" style={{ borderBottom: `1px solid ${C.border}` }}>
              <p style={{ color: C.text, fontWeight: 600, fontSize: "0.9rem" }}>Recent Inventory Alerts</p>
              <button onClick={() => onNavigate("alerts")}
                className="flex items-center gap-1 text-xs transition-colors"
                style={{ background: "none", border: "none", color: C.cyan, fontWeight: 500 }}>
                View all <ArrowUpRight className="w-3 h-3" />
              </button>
            </div>
            <div>
              {recentAlerts.map((alert) => (
                <div key={alert.item} className="flex items-center gap-4 px-5 py-3.5" style={{ borderBottom: `1px solid rgba(255,255,255,0.03)` }}>
                  <span className="w-2 h-2 rounded-full shrink-0" style={{ background: levelColors[alert.level] }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm" style={{ color: C.text, fontWeight: 500 }}>{alert.item}</p>
                    <p className="text-xs" style={{ color: C.muted }}>
                      Excess: <span style={{ color: levelColors[alert.level] }}>{alert.excess}</span>
                      <span className="mx-1.5 opacity-30">·</span>
                      Expires in <span style={{ color: alert.expires.startsWith("1") ? "#FF6B6B" : C.yellow }}>{alert.expires}</span>
                    </p>
                  </div>
                  <span className="px-2 py-0.5 rounded-md text-xs" style={{ background: `${levelColors[alert.level]}20`, color: levelColors[alert.level], fontWeight: 600, textTransform: "uppercase", fontSize: "0.6rem", letterSpacing: "0.05em" }}>
                    {alert.level}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Stats + CTA */}
          <div className="flex flex-col gap-4">
            <div className="rounded-2xl p-5 flex-1" style={{ background: C.card, border: `1px solid ${C.border}` }}>
              <p style={{ color: C.text, fontWeight: 600, fontSize: "0.9rem", marginBottom: "1rem" }}>Performance</p>
              <div className="space-y-3">
                {[
                  { label: "Stock used this week", value: "78%", color: C.cyan },
                  { label: "Orders fulfilled", value: "96%", color: C.green },
                  { label: "Waste rate", value: "4.2%", color: "#FF6B6B" },
                ].map((s) => (
                  <div key={s.label}>
                    <div className="flex justify-between text-xs mb-1">
                      <span style={{ color: C.muted }}>{s.label}</span>
                      <span style={{ color: s.color, fontWeight: 700 }}>{s.value}</span>
                    </div>
                    <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
                      <div className="h-1.5 rounded-full" style={{ width: s.value, background: s.color, opacity: 0.8 }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-2xl p-5" style={{ background: `linear-gradient(135deg, rgba(91,238,252,0.15), rgba(22,246,134,0.15))`, border: `1px solid rgba(91,238,252,0.2)` }}>
              <Leaf className="w-5 h-5 mb-2" style={{ color: C.green }} />
              <p style={{ color: C.text, fontWeight: 700, fontSize: "0.875rem" }}>Upload Today's Sales</p>
              <p className="text-xs mb-3" style={{ color: C.muted }}>Keep AI suggestions up to date</p>
              <button onClick={() => onNavigate("sales")}
                className="px-4 py-2 rounded-xl text-xs transition-all hover:opacity-90"
                style={{ background: C.cyan, color: C.bg, fontWeight: 700 }}>
                Upload Now
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
