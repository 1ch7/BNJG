import React from "react";
import { LayoutDashboard, UploadCloud, AlertTriangle, BarChart2, Leaf, LogOut, Settings, ChevronRight } from "lucide-react";
import type { View } from "./types";

export type { View };

const C = {
  bg: "#151A1F", card: "#1A2027", border: "rgba(255,255,255,0.07)",
  cyan: "#5BEEFC", green: "#16F686", yellow: "#EEE638",
  text: "#FFFFFF", muted: "rgba(255,255,255,0.45)",
};

interface SidebarProps {
  activeView: View;
  onNavigate: (view: View) => void;
  onLogout: () => void;
}

const navItems: { id: View; label: string; icon: React.ElementType; badge?: number }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "sales", label: "Daily Sales", icon: UploadCloud },
  { id: "alerts", label: "Inventory Alerts", icon: AlertTriangle, badge: 4 },
  { id: "analytics", label: "Analytics & Trends", icon: BarChart2 },
];

export function Sidebar({ activeView, onNavigate, onLogout }: SidebarProps) {
  return (
    <aside className="flex flex-col w-60 shrink-0 h-full" style={{ background: C.card, borderRight: `1px solid ${C.border}` }}>
      {/* Logo */}
      <div className="px-5 py-5" style={{ borderBottom: `1px solid ${C.border}` }}>
        <div className="flex items-center gap-2.5">
          <div className="flex items-center justify-center w-8 h-8 rounded-xl" style={{ background: `linear-gradient(135deg, ${C.cyan}, ${C.green})` }}>
            <Leaf className="w-4 h-4" style={{ color: C.bg }} />
          </div>
          <div>
            <p className="leading-none" style={{ color: C.text, fontWeight: 700, fontSize: "0.8rem" }}>BNJGFood</p>
            <p className="leading-none mt-0.5" style={{ color: C.muted, fontSize: "0.65rem" }}>Solutions</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <p className="px-3 mb-2 uppercase tracking-wider" style={{ color: C.muted, fontSize: "0.6rem", fontWeight: 600 }}>Main Menu</p>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-left"
              style={{
                background: isActive ? "rgba(91,238,252,0.12)" : "transparent",
                color: isActive ? C.cyan : C.muted,
                border: isActive ? `1px solid rgba(91,238,252,0.25)` : "1px solid transparent",
              }}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span className="flex-1 text-sm" style={{ fontWeight: isActive ? 600 : 400 }}>{item.label}</span>
              {item.badge && !isActive && (
                <span className="flex items-center justify-center w-5 h-5 rounded-full shrink-0"
                  style={{ background: C.yellow, color: C.bg, fontSize: "0.6rem", fontWeight: 700 }}>
                  {item.badge}
                </span>
              )}
              {isActive && <ChevronRight className="w-3.5 h-3.5 opacity-70 shrink-0" />}
            </button>
          );
        })}
      </nav>

      {/* Bottom */}
      <div className="px-3 py-4 space-y-1" style={{ borderTop: `1px solid ${C.border}` }}>
        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors text-left"
          style={{ background: "none", color: C.muted }}>
          <Settings className="w-4 h-4" />
          <span className="text-sm">Settings</span>
        </button>
        <div className="flex items-center gap-3 px-3 py-3 rounded-xl mt-2" style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${C.border}` }}>
          <div className="w-8 h-8 rounded-xl flex items-center justify-center text-xs shrink-0"
            style={{ background: `linear-gradient(135deg, ${C.cyan}, ${C.green})`, color: C.bg, fontWeight: 700 }}>
            MR
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs truncate" style={{ color: C.text, fontWeight: 600 }}>Marco Rossi</p>
            <p className="text-xs truncate" style={{ color: C.muted }}>Restaurant Manager</p>
          </div>
          <button onClick={onLogout} className="shrink-0 transition-colors"
            style={{ background: "none", border: "none", color: C.muted }}>
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </aside>
  );
}
