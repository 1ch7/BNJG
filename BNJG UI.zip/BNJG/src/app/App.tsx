import { useState } from "react";
import { LoginScreen } from "./components/LoginScreen";
import { OnboardingUpload } from "./components/OnboardingUpload";
import { Sidebar } from "./components/Sidebar";
import { DashboardOverview } from "./components/DashboardOverview";
import { DailySalesView } from "./components/DailySalesView";
import { InventoryAlertsView } from "./components/InventoryAlertsView";
import { AnalyticsView } from "./components/AnalyticsView";
import type { View } from "./components/types";

type AppState = "login" | "onboarding" | "app";

export default function App() {
  const [appState, setAppState] = useState<AppState>("login");
  const [activeView, setActiveView] = useState<View>("dashboard");

  if (appState === "login") {
    return <LoginScreen onLogin={() => setAppState("onboarding")} />;
  }

  if (appState === "onboarding") {
    return <OnboardingUpload onComplete={() => setAppState("app")} />;
  }

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: "#f8fafc" }}>
      <Sidebar
        activeView={activeView}
        onNavigate={setActiveView}
        onLogout={() => { setAppState("login"); setActiveView("dashboard"); }}
      />
      {activeView === "dashboard" && <DashboardOverview onNavigate={setActiveView} />}
      {activeView === "sales" && <DailySalesView />}
      {activeView === "alerts" && <InventoryAlertsView />}
      {activeView === "analytics" && <AnalyticsView />}
    </div>
  );
}
